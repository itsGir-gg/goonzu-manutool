#include "RecipeModel.h"
#include "RecipeRegistrationHelpers.h"
#include "RecipeModules.h"

using namespace recipes;

void recipes::RegisterOtherRecipes() {
    AddRecipe(L"Arrow", 200, {
        Mat(L"Bamboo", 1),
        Mat(L"Iron Ore", 1),
        Mat(L"Feather", 1),
        });
    AddRecipe(L"Bullet", 200, {
        Mat(L"Copper", 1),
        Mat(L"Coal", 1),
        Mat(L"Sulfur", 1),
        });
}